import os

from flask import Flask
from flask_slack import Slack


class GameException(Exception):
    """Exception wrapper for exceptions to be passed to the user"""
    pass


class Stalemate(Exception):
    pass


class Board(object):
    """
    An implementation of a board which uses a simple array of 9 items.
        X = 1
        O = -1
        blank = 0
    The array index to board mapping is as follows:

    0|1|2
    -----
    3|4|5
    -----
    6|7|8

    Where the spots the user inputs is n + 1 (1-9)

    This allows us to simply sum the scorable subsets (columns, diagonals etc) where +3 = X win,
     and -3 = O win
    """
    WIN_SETS = ((0, 1, 2), (3, 4, 5), (6, 7, 8),  # rows
                (0, 3, 6), (1, 4, 7), (2, 5, 8),  # columns
                (0, 4, 8), (6, 4, 2)  # diagonals
                )

    def __init__(self, room, x_user, o_user):
        self.room = room  # the room the chat is happening in
        self.x_user, self.o_user = x_user, o_user
        self.players = {x_user, o_user}
        self.score_tokens = {x_user: 1, o_user: -1}  # internal tokens for score keeping
        self.next_turn = x_user  # x always goes first
        self.board = [0] * 9  # initialize the board
        self.spots_left = set(range(9)) # spots for O(1) lookup

    def make_move(self, user, spot):
        # Make sure its the users turn
        if not user == self.next_turn:
            raise GameException("Not user {}'s turn. It is {}'s turn.".format(user, self.next_turn))
        # Make sure the user's input is actually a digit
        if isinstance(spot, basestring) and not spot.isdigit():
            raise GameException("Spot must be a digit")
        spot = int(spot) - 1
        # Make sure the user's input is in the correct range
        if not 0 <= spot <= 8:
            raise GameException("Spot choices must be between 1 and 9")
        # Make sure the spot is still 0 (no move was made on the board)
        if spot not in self.spots_left:
            raise GameException("Spot {} already taken".format(spot + 1))
        else:
            self.board[spot] = self.score_tokens[user]
            self.spots_left -= {spot}
            self.next_turn = list(self.players - {user})[0]


    def check_board(self):
        # Iterate rows, columns, board
        for win_set in self.WIN_SETS:
            plays = []
            for position in win_set:
                plays.append(self.board[position])

            total = sum(plays)
            if total == 3:
                return self.x_user
            elif total == -3:
                return self.o_user
        if not self.spots_left:
            raise Stalemate('Stalemate')
        else:
            # No winner yet.
            return None



    def to_string(self):
        board = []

        for spot, current_play in enumerate(self.board, start=1):
            if current_play == 0:
                # Put in spot in rendering
                board.append(str(spot))
            elif current_play == -1:
                board.append('O')
            elif current_play == 1:
                board.append('X')

        table_string = '\n'
        rows = [board[:3], board[3:6], board[6:9]]
        for i, row in enumerate(rows, start=1):
            row_print = ' | '.join(row)
            table_string += row_print
            if i != len(rows):
                table_string += '\n---------\n'
        return table_string + '\n'




class BoardMemoryStore(object):
    def __init__(self):
        """
        A place to store our game boards. All you need to implement is a get_board and set_board
        so this can be replaced with a database/filesystem implementation when needed.
        """
        self.boards = {}

    def get_board(self, room):
        """Returns None if board doesnt exist"""
        return self.boards.get(room)

    def set_board(self, room, board):
        """Set to None to remove the board, keeps api simple for interface implementors"""
        if board is None and room in self.boards:
            del self.boards[room]
        else:
            self.boards[room] = board


flask_app = Flask('ttt')
slack = Slack(flask_app)
store = BoardMemoryStore()
flask_app.add_url_rule('/', view_func=slack.dispatch)
# Pull token from environment to avoid secrets in the code (source local_dev locally for development)
slack_token = os.environ['SLACK_TOKEN']
slack_team_id = os.environ['SLACK_TEAM_ID']


# Slack interactions
def response_in_channel(text):
    return slack.response(text, response_type='in_channel')

@slack.command('ttt', token=slack_token,
                team_id=slack_team_id,
                methods=['POST'])
def command_ttt(**kwargs):
    try:
        text = kwargs.get('text').strip()
        if not text:
            return slack.response("No command recieved. '/ttt' @player to challenge someone")
        room = kwargs['channel_id']
        user = kwargs['user_name']
        board = store.get_board(room)
        if '@' in text:
            parts = text.split('@')
            if len(parts) > 2:
                return response_in_channel('Only one @ allowed to challenge people')
            if board:
                return response_in_channel('Game already running. Please use \'/ttt end\' to end')
            challenged_user = parts[1].strip().split(' ')[0]
            if challenged_user == user:
                return response_in_channel("You can't play yourself!")
            board = Board(room, user, challenged_user)
            store.set_board(room, board)
            return response_in_channel(
                'Game started between {x_user} (x) and {o_user} (o). x goes first!\n'
                'To Play:\n'
                '    /ttt <int position of 1-9>.\n'
                '    /ttt end to end game.\n'
                '{board}'.format(x_user=board.x_user, o_user=board.o_user, board=board.to_string()))
        if text == 'end':
            store.set_board(room, None)
            return response_in_channel('Game ended!')
        if not board:
            return response_in_channel("No game started. /ttt @player to start.")
        if text.isdigit():
            board.make_move(user, int(text))
            try:
                result = board.check_board()
                if result:
                    store.set_board(room, None)
                    return response_in_channel('Game ended! {} won!'.format(user))
            except Stalemate:
                store.set_board(room, None)
                return response_in_channel("Game ended in a stalemate".format(text))
            return response_in_channel("User {} moved to {}\n {board}".format(user, text, board=board.to_string()))
        return response_in_channel("Unknown command: {}".format(text))
    except GameException as e:
        return response_in_channel(e.message)


def main():
    port = int(os.environ.get("PORT", 5000))
    flask_app.run(host='0.0.0.0', port=port)


if __name__ == '__main__':
   main()